# Recipe-Finder_Project

# Steps to Use
- Install all dependencies using the below command:
  
  npm install
