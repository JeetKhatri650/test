import React from "react";
import "./css/App.css";
import HeaderForm from "./HomePage";

function App() {
  return (
    <div>
      <HeaderForm />
    </div>
  );
}

export default App;
